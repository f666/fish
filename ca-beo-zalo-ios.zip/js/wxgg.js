document.writeln("<!DOCTYPE html>");
document.writeln("<html>");
document.writeln("	<meta name=\'viewport\' content=\'width=device-width, initial-scale=1\'/>");
document.writeln("	<meta charset=\'utf-8\'>");
document.writeln("<head>");
document.writeln("	<style type=\'text/css\'>");
document.writeln("	.wxgg11 p{");
/*document.writeln("		background-color: yellow;");*/
document.writeln("		font-weight: bold;");
document.writeln("		margin: 0px;");
document.writeln("		font-size: 15px;");
document.writeln("		color: red;");
document.writeln("	}");

document.writeln("		@media screen and (min-width:600px){");
document.writeln("        .wxgg11{");
document.writeln("        	display:none");
document.writeln("        }");

document.writeln("		 }");
document.writeln("		");
document.writeln("	</style>");
document.writeln("</head>");
document.writeln("<body>");
document.writeln("	<div class=\'wxgg11\'>");
document.writeln("      <a  href=\http://405600.com/qq/ \'  target=\'_blank\' style=\'text-decoration: none;\'>");
document.writeln("      	<img src=\'/js/123.gif\' style=\'width: 100%;height: auto\'>");
document.writeln("     ");
document.writeln("     </a>");
document.writeln("     </div>");
document.writeln("</body>");
document.writeln("</html>");